<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Repositories\Cart\CartInterface;
use App\Repositories\Item\ItemInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class CartController extends Controller
{
    protected $cartInterface;
    protected $itemInterface;
    public function __construct(
        CartInterface $cartInterface,
        ItemInterface $itemInterface
    )
    {
        $this->cartInterface = $cartInterface;
        $this->itemInterface = $itemInterface;
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/cart/add-product-to-cart",
     *     tags={"APP Giỏ hàng"},
     *     summary="Thêm sản phẩm vào giỏ hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="cart/add-product-to-cart",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="itemId", type="string"),
     *              @OA\Property(property="number", type="string"),
     *              @OA\Property(property="size", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "itemId": "3",
     *                  "number": "7",
     *                  "size": "L",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function addProductToCart(Request $request){
        try {
            DB::beginTransaction();
            $userId = $this->getCurrentLoggedIn()->userId;
            $this->cartInterface->addProductToCart($request, $userId);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/cart/get-cart",
     *     tags={"APP Giỏ hàng"},
     *     summary="Chi tiết giỏ hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="cart/get-cart",
     *      @OA\RequestBody(
     *           @OA\JsonContent(
     *               type="object",
     *               @OA\Property(
     *                   property="id",
     *                   type="array",
     *                   description="Array id",
     *                   @OA\Items(
     *                       type="integer",
     *                       example=0
     *                   )
     *               ),
     *           )
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getCart(Request $request)
    {
        try {
            DB::beginTransaction();
            $products = $this->cartInterface->getCart($request->id, $this->getCurrentLoggedIn()->userId);
            $data = [];
            foreach ($products as $product){
                $data[] = ['item_info' => $this->itemInterface->getItem($product['itemId']),
                            'item' => $product];
            }
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/cart/update-cart",
     *     tags={"APP Giỏ hàng"},
     *     summary="Cập nhật giỏ hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-cart",
     *     @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  type="array",
     *                  @OA\Items(
     *                      type="object",
     *                      @OA\Property(property="id", type="integer", description="ID của sản phẩm trong giỏ"),
     *                      @OA\Property(property="number", type="integer", description="Số lượng mới")
     *                  )
     *              )
     *          )
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function updateCart(Request $request)
    {
        try {
            DB::beginTransaction();
            $userId = $this->getCurrentLoggedIn()->userId;
            $data = $request->all();
            foreach($data as $datum){
                $this->cartInterface->updateCart($userId, $datum);
            }
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Delete (
     *     path="/api/app/cart/delete-product-in-cart",
     *     tags={"APP Giỏ hàng"},
     *     summary="Xóa sản phẩm trong giỏ hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="delete-product-in-cart",
     *     @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  type="object",
     *                  required={"id"},
     *                  @OA\Property(
     *                      property="id",
     *                      type="array",
     *                      @OA\Items(type="integer")
     *                  )
     *              )
     *          )
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function deleteItemInCart(Request $request)
    {
        try {
            DB::beginTransaction();
            $userId = $this->getCurrentLoggedIn()->userId;
            $data = $this->cartInterface->deleteItemInCart($userId, $request->id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
