<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CMS\MediaRequest;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\User\AuthRequest;
use App\Models\File;
use App\Models\User;
use App\Models\Account;
use App\Repositories\Cart\CartInterface;
use App\Services\User\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\User\UserInterface;
use Media;
class AuthController extends Controller
{
    private AuthService $authService;
    private User $user;
    protected $cartInterface;
    public function __construct(
        AuthService $authService,
        User $user,
        Account $account,
        CartInterface $cartInterface
    )
    {
        $this->authService = $authService;
        $this->user = $user;
        $this->account = $account;
        $this->cartInterface = $cartInterface;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/auth/get-user",
     *     tags={"APP Tài khoản"},
     *     summary="Thông tin tài khoản",
     *     security={{"bearerAuth":{}}},
     *     operationId="auth/get-user",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
        public function getUser()
    {
        try {
            $user = $this->user->where('id', $this->getCurrentLoggedIn()->userId)->first();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $user
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/auth/register",
     *     tags={"APP Tài khoản"},
     *     summary="Đăng ký",
     *     operationId="users/create",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="userName", type="string"),
     *              @OA\Property(property="name", type="string"),
     *              @OA\Property(property="phone", type="string"),
     *              @OA\Property(property="email", type="string"),
     *              @OA\Property(property="password", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "userName": "sonnk",
     *                  "name": "Nguyen Van A",
     *                  "phone": "0123456789",
     *                  "email": "sownnk@gmail.com",
     *                  "password": "123123",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function createUser(RegisterRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();
            $data = $this->user->create([
                'email' => $request->email,
                'name' => $request->name,
                'phone' => $request->phone,
                'branch' => '1',
                'roleId' => User::$user,
            ])->id;
            $this->account->create([
                'userName' => $request->userName,
                'password' => Hash::make($request->password),
                'typeAccount' => '1',
                'status' => '1',
                'userId' => $data,
                'roleId' => User::$user,
            ]);
            $this->cartInterface->createCart($data);
            DB::commit();

            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {

            DB::rollBack();

            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage()
            ], Constant::INTERNAL_SV_ERROR_CODE);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/auth/login",
     *     tags={"APP Tài khoản"},
     *     summary="Đăng nhập User",
     *     operationId="users/login/user",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="userName", type="string"),
     *              @OA\Property(property="password", type="string"),
     *              @OA\Property(property="device_token", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "userName": "sonnk",
     *                  "password": "123123",
     *                  "device_token": "xxx111xxx",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function login(AuthRequest $request): JsonResponse
    {
        try {
            $user = $this->account->ofUserName($request->userName)
                ->OfRole(Account::$user)
                ->first();

            if (!$user) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_1',
                    'message' => trans('messages.errors.users.email_not_found'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            if ($user->status == 0) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_2',
                    'message' => trans('messages.errors.users.account_not_active'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            $credentials = [
                'userName' => $request->userName,
                'password' => $request->password
            ];

            if (!Auth::attempt($credentials)) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_3',
                    'message' => trans('messages.errors.users.password_not_correct'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }


            // xoa token cu
            $user->tokens()->delete();

            $user->update([
                'device_token' => $request->device_token
            ]);

            Log::debug($request);
            $data = [
                'token' => $user->createToken($request->device_token)->plainTextToken,
                'user' => $user
            ];

            return response()->json([
                'status' => Response::HTTP_OK,
                'message' => trans('messages.success.users.login_success'),
                'data' => $data
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/auth/logout",
     *     tags={"APP Tài khoản"},
     *     summary="Đăng xuất",
     *     security={{"bearerAuth":{}}},
     *     operationId="users/logout/user",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function logout(): JsonResponse
    {
        try {
            DB::beginTransaction();

            $user = $this->getCurrentLoggedIn();

            if ($user) {
                $user->tokens()->delete();
            } else {
                abort(Constant::UNAUTHORIZED_CODE);
            }

            DB::commit();

            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => 'Đăng xuất thành công!',
                'data' => $user
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/auth/edit-profile",
     *     tags={"APP Tài khoản"},
     *     summary="Chỉnh sửa thông tin cá nhân",
     *     security={{"bearerAuth":{}}},
     *     operationId="users/edit-profile",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="name", type="string"),
     *              @OA\Property(property="phone", type="string"),
     *              @OA\Property(property="email", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "name": "Nguyen Van B",
     *                  "phone": "0987654321",
     *                  "email": "emailedit@gmail.com",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function editProfile(AuthRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();

            $user = $this->user->where('id', $this->getCurrentLoggedIn()->userId)->first();
            $data = $request->only('name', 'phone', 'email');

            $this->user->find($user->id)->update($data);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => User::find($user->id)
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/auth/change-password",
     *     tags={"APP Tài khoản"},
     *     summary="Đổi mật khẩu",
     *     security={{"bearerAuth":{}}},
     *     operationId="users/change-password",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="old_password", type="string"),
     *              @OA\Property(property="new_password", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "old_password": "123123",
     *                  "new_password": "123456",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function changePassword(AuthRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();
            $user = $this->getCurrentLoggedIn();
            $old_password = $request->old_password;
            $new_password = $request->new_password;

            $user = Account::find($user->id);
            if(!Hash::check($old_password, $user->password)){
                DB::rollBack();
                    return response()->json([
                        'status' => Response::HTTP_BAD_REQUEST,
                        'message' => trans('messages.errors.users.password_not_correct'),
                        'data' => []
                    ], Response::HTTP_BAD_REQUEST);
            }

            $user->update(['password'=> Hash::make($new_password)]);

            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => User::find($user->id)
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/auth/change-avatar",
     *     tags={"APP Tài khoản"},
     *     summary="Đổi ảnh đại diện",
     *     security={{"bearerAuth":{}}},
     *     operationId="users/change-avatar",
     *     @OA\RequestBody(
     *           @OA\MediaType(
     *               mediaType="multipart/form-data",
     *               @OA\Schema(
     *                   allOf={
     *                       @OA\Schema(
     *                            @OA\Property(property="file", type="string", format="binary", example=1),
     *                      )
     *                   }
     *               )
     *           )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function changeAvatar(MediaRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();
            $user_id = Auth::id();
            $user = Auth::user();
            if(empty($user_id)){
                DB::rollBack();
                return response()->json([
                    'status' => Constant::FALSE_CODE,
                    'message' => trans('messages.errors.road.not_found'),
                    'data'=>[]
                ], Constant::INTERNAL_SV_ERROR_CODE);
            }
            $file = $request->file('file');
            if ($request->hasFile('file')) {
                if(!empty($user->avatar)){
                    Media::deleteFile($user->avatar, Constant::PATH_UPLOAD);
                }

                $pathAvatar = Media::handleUploadFile($file, false, 0, Constant::PATH_AVATAR);
                if (isset($pathAvatar['error'])) {
                    return response()->json([
                        'status' => Constant::BAD_REQUEST_CODE,
                        'message' => $pathAvatar['message'],
                        'data' => []
                    ], Constant::BAD_REQUEST_CODE);
                }
                $image = $pathAvatar['url'];
            }
            $user = User::find($user_id);
            $user['avatar'] = $image;
            $user->save();

            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $image
            ], Constant::SUCCESS_CODE);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => Constant::BAD_REQUEST_CODE,
                'message' => $e->getMessage(),
                'data' => []
            ], Constant::BAD_REQUEST_CODE);
        }

    }
}
//public function function($request)
//{
//    try {
//        DB::beginTransaction();
//        DB::commit();
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' => User::find($user->id)
//        ], Constant::SUCCESS_CODE);
//
//    } catch (\Throwable $th) {
//        return response()->json([
//            'status' => Constant::FALSE_CODE,
//            'message' => $th->getMessage(),
//            'data' => []
//        ], Response::HTTP_INTERNAL_SERVER_ERROR);
//    }
//}
