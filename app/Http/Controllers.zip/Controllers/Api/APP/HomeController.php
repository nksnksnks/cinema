<?php
//
//namespace App\Http\Controllers\Api\APP;
//
//use App\Enums\Constant;
//use App\Helpers\CommonHelper;
//use App\Repositories\Home\HomeInterface;
//use Illuminate\Support\Facades\DB;
//use Illuminate\Support\Facades\Log;
//use App\Http\Controllers\Controller;
//use Illuminate\Http\Request;
//use Symfony\Component\HttpFoundation\Response;
//
//class HomeController extends Controller
//{
//    private $homeRepository;
//    private $endpoint;
//    private $partnerCode;
//    private $accessKey;
//    private $orderInfo;
//    private $requestType;
//    private $redirectUrl;
//    private $ipnUrl;
//    public function __construct(
//        HomeInterface $homeRepository
//    )
//    {
//        $this->homeRepository = $homeRepository;
//        $this->endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";
//        $this->partnerCode = 'MOMOBKUN20180529';
//        $this->accessKey = 'klm05TvNBzhg7h7j';
//        $this->secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';
//        $this->orderInfo = "Thanh toán qua MoMo";
//        $this->requestType = "captureWallet";
//        $this->redirectUrl = "http://127.0.0.1:8000/api/app/home/voucher";
//        $this->ipnUrl = "http://127.0.0.1:8000/api/app/home/voucher";
//    }
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/app/home/momo-payment",
//     *     tags={"APP Thanh toán"},
//     *     summary="Thanh toán Momo",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="home/momo-payment",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *     @OA\RequestBody(
//     *          @OA\JsonContent(
//     *              type="object",
//     *              @OA\Property(property="orderId", type="string"),
//     *              @OA\Property(property="amount", type="string"),
//     *          @OA\Examples(
//     *              summary="Examples",
//     *              example = "Examples",
//     *              value = {
//     *                  "orderId": "1",
//     *                  "amount": "1000000"
//     *                  },
//     *              ),
//     *          )
//     *     ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function momoPayment(Request $request){
//        $endpoint = $this->endpoint;
//        $partnerCode = $this->partnerCode;
//        $accessKey = $this->accessKey;
//        $secretKey = $this->secretKey;
//        $orderInfo = $this->orderInfo;
//        $amount = $request->amount;
//        $orderId = $request->orderId;
//        $redirectUrl = $this->redirectUrl;
//        $ipnUrl = $this->ipnUrl;
//        $extraData = "";
//        $requestId = time() . "";
//        $requestType = $this->requestType;
//        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
//        $signature = hash_hmac("sha256", $rawHash, $secretKey);
//        $data = array('partnerCode' => $partnerCode,
//            'partnerName' => "Test",
//            "storeId" => "MomoTestStore",
//            'requestId' => $requestId,
//            'amount' => $amount,
//            'orderId' => $orderId,
//            'orderInfo' => $orderInfo,
//            'redirectUrl' => $redirectUrl,
//            'ipnUrl' => $ipnUrl,
//            'lang' => 'vi',
//            'extraData' => $extraData,
//            'requestType' => $requestType,
//            'signature' => $signature);
//        $result = CommonHelper::execPostRequest($endpoint, json_encode($data));
//        $jsonResult = json_decode($result, true);
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' => $jsonResult
//        ], Constant::SUCCESS_CODE);
//    }
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/app/home/momo-payment",
//     *     tags={"APP Thanh toán"},
//     *     summary="Thanh toán Momo",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="home/momo-payment",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *     @OA\RequestBody(
//     *          @OA\JsonContent(
//     *              type="object",
//     *              @OA\Property(property="orderId", type="string"),
//     *              @OA\Property(property="amount", type="string"),
//     *          @OA\Examples(
//     *              summary="Examples",
//     *              example = "Examples",
//     *              value = {
//     *                  "orderId": "1",
//     *                  "amount": "1000000"
//     *                  },
//     *              ),
//     *          )
//     *     ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//}
