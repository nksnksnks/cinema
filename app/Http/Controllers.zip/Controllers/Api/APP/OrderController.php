<?php
//
//namespace App\Http\Controllers\Api\APP;
//
//use App\Enums\Constant;
//use App\Http\Controllers\Controller;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
//use Symfony\Component\HttpFoundation\Response;
//
//class OrderController extends Controller
//{
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/app/order/get-temporary-order",
//     *     tags={"APP Đơn hàng"},
//     *     summary="Đơn hàng tạm thời",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="get-temporary-order",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function getTemporaryOrder($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/app/order/get-order",
//     *     tags={"APP Đơn hàng"},
//     *     summary="Chi tiết đơn hàng",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="get-order",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function getOrder($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/app/order/create-order",
//     *     tags={"APP Đơn hàng"},
//     *     summary="Tạo đơn hàng",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="create-order",
//
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function createOrder(Request $request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//}
