<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Address;
use App\Models\User;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;


class AddressController extends Controller
{
    private Address $address;
    private User $user;
    public function __construct(
        Address $address,
        User $user
    )
    {
        $this->address = $address;
        $this->user = $user;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/address/get-address",
     *     tags={"APP Quản lý địa chỉ"},
     *     summary="Chi tiết địa chỉ",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-address",
     *     @OA\Parameter(
     *           in="query",
     *           name="id",
     *           required=true,
     *           description="id",
     *           @OA\Schema(
     *             type="string",
     *             example="1",
     *           ),
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getAddress(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $this->address->where('id', $request->id)->get();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/address/get-list-address",
     *     tags={"APP Quản lý địa chỉ"},
     *     summary="Danh sách địa chỉ",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-cart",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListAddress()
    {
        try {
            $data = $this->address->select('id', 'city', 'district', 'ward', 'note', 'phone', 'name')->where('customerId', '=', $this->getCurrentLoggedIn()->userId)->get();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/address/create-address",
     *     tags={"APP Quản lý địa chỉ"},
     *     summary="Thêm mới địa chỉ",
     *     security={{"bearerAuth":{}}},
     *     operationId="create-address",
     *     @OA\RequestBody(
     *           @OA\JsonContent(
     *               type="object",
     *               @OA\Property(property="city", type="string"),
     *               @OA\Property(property="district", type="string"),
     *               @OA\Property(property="ward", type="string"),
     *               @OA\Property(property="note", type="string"),
     *               @OA\Property(property="name", type="string"),
     *               @OA\Property(property="phone", type="string"),
     *           @OA\Examples(
     *               summary="Examples",
     *               example = "Examples",
     *               value = {
     *                   "city": "Hà Nội",
     *                   "district": "Đống Đa",
     *                   "ward": "Láng Hạ",
     *                   "note": "Số 112 đường Vũ Ngọc Phan",
     *                   "name": "Nguyễn Văn A",
     *                   "phone": "0123456789"
     *                   },
     *               ),
     *           )
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function createAddress(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $datas = $this->address->create([
                'city' => $data['city'],
                'district' => $data['district'],
                'ward' => $data['ward'],
                'note' => $data['note'],
                'name' => $data['name'],
                'phone' => $data['phone'],
                'customerId' => $this->getCurrentLoggedIn()->userId
            ]);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $datas
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/address/update-address/{id}",
     *     tags={"APP Quản lý địa chỉ"},
     *     summary="Cập nhật địa chỉ",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-address",
     *     @OA\Parameter(
     *           in="path",
     *           name="id",
     *           required=true,
     *           description="id",
     *           @OA\Schema(
     *             type="integer",
     *             example=6,
     *           )
     *      ),
     *     @OA\RequestBody(
     *            @OA\JsonContent(
     *                type="object",
     *                @OA\Property(property="city", type="string"),
     *                @OA\Property(property="district", type="string"),
     *                @OA\Property(property="ward", type="string"),
     *                @OA\Property(property="note", type="string"),
     *                @OA\Property(property="phone", type="string"),
     *            @OA\Examples(
     *                summary="Examples",
     *                example = "Examples",
     *                value = {
     *                    "city": "Hà Nội",
     *                    "district": "Đống Đa",
     *                    "ward": "Láng Hạ",
     *                    "note": "Số 119 đường Vũ Ngọc Phan",
     *                    "phone": "0987654321"
     *                    },
     *                ),
     *            )
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function updateAddress($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $this->address->find(2)->update($data);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Delete (
     *     path="/api/app/address/delete-address/{id}",
     *     tags={"APP Quản lý địa chỉ"},
     *     summary="Xóa địa chỉ",
     *     security={{"bearerAuth":{}}},
     *     operationId="delete-address",
     *     @OA\Parameter(
     *            in="path",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="integer",
     *              example=4,
     *            )
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function deleteAddress($id)
    {
        try {
            DB::beginTransaction();
            $this->address->find($id)->delete();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
