<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Helpers\CommonHelper;
use App\Repositories\Bill\BillInterface;
use App\Repositories\Home\HomeInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Carbon;

class PaymentController extends Controller
{
    protected $billInterface;
    private $endpoint;
    private $partnerCode;
    private $accessKey;
    private $orderInfo;
    private $requestType;
    private $redirectUrl;
    private $ipnUrl;
    public function __construct(
        BillInterface $billInterface
    )
    {
        $this->billInterface = $billInterface;
        $this->endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";
        $this->partnerCode = 'MOMOBKUN20180529';
        $this->accessKey = 'klm05TvNBzhg7h7j';
        $this->secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';
        $this->orderInfo = "Thanh toán qua MoMo";
        $this->requestType = "captureWallet";
        $this->redirectUrl = "http://localhost:3000/cart";
        $this->ipnUrl = "http://localhost:3000/cart";
    }
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/app/payment/momo-payment",
//     *     tags={"APP Thanh toán"},
//     *     summary="Thanh toán Momo",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="payment/momo-payment",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *     @OA\RequestBody(
//     *          @OA\JsonContent(
//     *              type="object",
//     *              @OA\Property(property="amount", type="string"),
//     *              @OA\Property(property="appointmentTime", type="string"),
//     *          @OA\Examples(
//     *              summary="Examples",
//     *              example = "Examples",
//     *              value = {
//     *                  "amount": "1000000",
//     *                  "billId": "1"
//     *                  },
//     *              ),
//     *          )
//     *     ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
    public function momoPayment($amount, $billId){
//        $this->appointmentTime = $request->appointmentTime;
        $endpoint = $this->endpoint;
        $partnerCode = $this->partnerCode;
        $accessKey = $this->accessKey;
        $secretKey = $this->secretKey;
        $orderInfo = $this->orderInfo;
        $orderId = $billId;
        $redirectUrl = $this->redirectUrl;
        $ipnUrl = $this->ipnUrl;
        $extraData = "";
        $requestId = time() . "";
        $requestType = $this->requestType;
        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
        $signature = hash_hmac("sha256", $rawHash, $secretKey);
        $data = array('partnerCode' => $partnerCode,
            'partnerName' => "Test",
            "storeId" => "MomoTestStore",
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'extraData' => $extraData,
            'requestType' => $requestType,
            'signature' => $signature,
//            'appointmentTime' => $this->appointmentTime
            );
        $result = CommonHelper::execPostRequest($endpoint, json_encode($data));
        $jsonResult = json_decode($result, true);
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' => $jsonResult
//        ], Constant::SUCCESS_CODE);
        return $jsonResult;
    }
    public function handleMomoPayment(Request $request){
        $responseData = $request->all();
        $partnerCode = $this->partnerCode;
        $accessKey = $this->accessKey;
        $secretKey = $this->secretKey;
        $orderInfo = $this->orderInfo;
        $amount = $responseData["amount"];
        $orderId = $responseData['orderId'];
        $extraData = "";
        $requestId = $responseData['requestId'];
        $signature = $responseData['signature'];
        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData .
            "&message=" . $responseData["message"] . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo .
            "&orderType=" . $responseData["orderType"] . "&partnerCode=" . $partnerCode . "&payType=" . $responseData["payType"] . "&requestId=" . $requestId .
            "&responseTime=" . $responseData["responseTime"] . "&resultCode=" . $responseData["resultCode"] . "&transId=" . $responseData["transId"];
        $generatedSignature = hash_hmac("sha256", $rawHash, $secretKey);
        if ($generatedSignature == $signature) {
            if($responseData['resultCode'] == '0') {
                $this->billInterface->updateBillPaid($orderId);
                return response()->json([
                    'status' => Constant::SUCCESS_CODE,
                    'message' => trans('messages.success.success'),
                    'data' => [0]
                ], Constant::SUCCESS_CODE);
            }
            else{
                $this->billInterface->updateBillCancel($orderId);
                return response()->json([
                    'status' => Constant::BAD_REQUEST_CODE,
                    'message' => trans('messages.errors.errors'),
                    'data' => [1]
                ], Constant::SUCCESS_CODE);
            }
        } else {
            $this->billInterface->updateBillCancel($orderId);
            return response()->json([
                'status' => Constant::BAD_REQUEST_CODE,
                'message' => trans('messages.errors.errors'),
                'data' => [1]
            ], Constant::SUCCESS_CODE);
        }
    }
}
