<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Models\Itemtype;
use Illuminate\Http\Request;
use App\Http\Requests\CMS\ItemTypeRequest;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
class CategoryController extends Controller
{
    protected Itemtype $itemtype;
    public function __construct(
        Itemtype $itemtype
    )
    {
        $this->itemtype = $itemtype;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/category/get-category",
     *     tags={"APP Danh mục"},
     *     summary="Tên danh mục",
     *     operationId="app-get-category",
     *     @OA\Parameter(
     *            in="query",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getCategory(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $this->itemtype->find($request->id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/category/get-list-category",
     *     tags={"APP Danh mục"},
     *     summary="Danh sách danh mục",
     *     operationId="app-get-list-category",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListCategory()
    {
        try {
            DB::beginTransaction();
            $data = $this->itemtype->get();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
