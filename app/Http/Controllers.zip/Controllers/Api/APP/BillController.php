<?php

namespace App\Http\Controllers\Api\APP;

use App\Enums\Constant;
use App\Events\BillPusherEvent;
use App\Models\Bill;
use App\Http\Controllers\Controller;
use App\Repositories\Bill\BillInterface;
use App\Repositories\Cart\CartInterface;
use App\Repositories\Item\ItemInterface;
use App\Repositories\ItemsOrder\ItemsOrderInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
class BillController extends Controller
{
    protected $cartInterface;
    protected $itemInterface;
    protected $billInterface;
    protected $itemsOrderInterface;
    protected $paymentController;
    public function __construct(
        CartInterface $cartInterface,
        ItemInterface $itemInterface,
        BillInterface $billInterface,
        ItemsOrderInterface $itemsOrderInterface,
        PaymentController $paymentController
    )
    {
        $this->cartInterface = $cartInterface;
        $this->itemInterface = $itemInterface;
        $this->billInterface = $billInterface;
        $this->itemsOrderInterface = $itemsOrderInterface;
        $this->paymentController = $paymentController;
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/app/bill/create-bill",
     *     tags={"APP Đơn hàng"},
     *     summary="Tạo đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="bill/create-bill",
     *      @OA\RequestBody(
     *           @OA\JsonContent(
     *               type="object",
     *               @OA\Property(
     *                   property="id",
     *                   type="array",
     *                   description="Array id",
     *                   @OA\Items(
     *                       type="integer",
     *                       example=0
     *                   )
     *               ),
     *              @OA\Property(property="addressId", type="string", example="1"),
     *              @OA\Property(property="appointmentTime", type="string", example="16:26 16/03/2024"),
     *              @OA\Property(property="paymentOptionId", type="string", example="1"),
     *              @OA\Property(property="deliveryOptionId", type="string", example="1"),
     *              @OA\Property(property="total", type="integer", example="50000"),
     *              @OA\Property(property="note", type="string", example="This is note"),
     *           )
     *
     *      ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function createBill(Request $request)
    {
        try {
            $data = $request->all();
            $customerId = $this->getCurrentLoggedIn()->userId;
            $billId = $this->billInterface->createBill($data, $customerId);
            if($data['paymentOptionId'] != Bill::MOMO_PAYMENT){
                $this->billInterface->updateBillPaid($billId['billId']);
            }
            $item = $this->cartInterface->getCart($data['id'], $customerId);
            $amount = $billId['total'];
            foreach($item as $i){
                $this->itemsOrderInterface->addItemsInBill($billId['billId'], $i);
                $this->cartInterface->softDeleteItemInCart($customerId, $i['id']);
            }
            if($data['paymentOptionId'] == Bill::MOMO_PAYMENT){
                $dataMomo = $this->paymentController->momoPayment($amount, $billId['uuid']);
                return response()->json([
                    'status' => Constant::SUCCESS_CODE,
                    'message' => trans('messages.success.success'),
                    'data' => $dataMomo
                ], Constant::SUCCESS_CODE);
            }
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    public function cancelBill(): void
    {
        $timeNow = Carbon\Carbon::now();
        $timeNow->subMinutes(value: 15);
        $data = Bill::where('status', Bill::PENDING)->where('updated_at', '<' , $timeNow)->get();
        foreach($data as $i){
            Bill::where('id', $i['id'])->update(['status' => Bill::CANCEL]);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/bill/get-list-bill",
     *     tags={"APP Đơn hàng"},
     *     summary="Danh sách đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-list-bill",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListBill()
    {
        try {
            $id = $this->getCurrentLoggedIn()->userId;
            $data = $this->billInterface->getListBill($id);
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/app/bill/get-bill-detail",
     *     tags={"APP Đơn hàng"},
     *     summary="Chi tiết đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-bill-detail",
     *     @OA\Parameter(
     *            in="query",
     *            name="billId",
     *            required=true,
     *            description="billId",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getBillDetail(Request $request)
    {
        try {
            $userId = $this->getCurrentLoggedIn()->userId;
            $data = $request->all();
            $billDetail = $this->billInterface->getBillDetail($userId, $data['billId']);
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $billDetail
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/app/bill/get-bill-detail",
//     *     tags={"APP Đơn hàng"},
//     *     summary="Chi tiết đơn hàng",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="get-bill-detail",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function deleteBill()
//    {
//
//    }
//    public function testPusher(Request $request){
//        $contents = $request->all();
//        event(new BillPusherEvent($contents));
//        return response()->json([
//            'status' => 'success',
//            'message' => 'Data pushed to Pusher successfully',
//            'data' => $contents
//        ]);
//    }
}
