<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Repositories\Dashboard\DashboardInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;


class DashBoardController extends Controller
{
    protected DashboardInterface $dashboardInterface;
    public function __construct(DashboardInterface $dashboardInterface)
    {
        $this->dashboardInterface = $dashboardInterface;
    }

    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-daily-revenue",
     *     tags={"CMS Dashboard"},
     *     summary="Doanh thu theo ngày",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-daily-revenue",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getDailyRevenue()
    {
        try {
            $data = $this->dashboardInterface->getDailyRevenue();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/dashboard/get-time-revenue",
     *     tags={"CMS Dashboard"},
     *     summary="Doanh thu theo khoảng thời gian",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-time-revenue",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *                 type="object",
     *                 @OA\Property(property="startDate", type="string"),
     *                 @OA\Property(property="endDate", type="string"),
     *          @OA\Examples(
     *                 summary="Examples",
     *                 example = "Examples",
     *                 value = {
     *                     "startDate": "2024/01/01",
     *                     "endDate":"2024/01/01",
     *                     },
     *                 ),
     *             )
     *        ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getTimeRevenue(Request $request)
    {
        try {
            $data = $this->dashboardInterface->getTimeRevenue($request);
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-month-item-top-revenue",
     *     tags={"CMS Dashboard"},
     *     summary="Doanh thu sản phẩm trong tháng",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-month-item-top-revenue",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getMonthItemTopRevenue()
    {
        try {
            $data = $this->dashboardInterface->getMonthItemTopRevenue();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-daily-item-top-revenue",
     *     tags={"CMS Dashboard"},
     *     summary="Doanh thu sản phẩm trong ngày",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-daily-item-top-revenue",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getDailyItemTopRevenue()
    {
        try {
            $data = $this->dashboardInterface->getDailyItemTopRevenue();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-week-item-top-revenue",
     *     tags={"CMS Dashboard"},
     *     summary="Doanh thu sản phẩm trong tuần",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-week-item-top-revenue",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getWeekItemTopRevenue()
    {
        try {
            $data = $this->dashboardInterface->getWeekItemTopRevenue();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-new-user-number",
     *     tags={"CMS Dashboard"},
     *     summary="Số lượng khách hàng mới",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-new-user-number",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function newUserNumber()
    {
        try {
            $data = $this->dashboardInterface->newUserNumber();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/dashboard/get-bill-number",
     *     tags={"CMS Dashboard"},
     *     summary="Số lượng đơn hàng trong 7 ngày",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-bill-number",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getBillNumber()
    {
        try {
            $data = $this->dashboardInterface->getBillNumber();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
