<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Models\Item;
use App\Repositories\Item\ItemInterface;
use Illuminate\Http\Request;
use App\Http\Requests\CMS\ItemRequest;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
class ItemController extends Controller
{
    protected Item $item;
    protected $itemInterface;
    public function __construct(
        Item $item,
        ItemInterface $itemInterface
    )
    {
        $this->item = $item;
        $this->itemInterface = $itemInterface;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/item/get-item",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Thông tin sản phẩm",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-item",
     *     @OA\Parameter(
     *            in="query",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getItem(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $this->itemInterface->getItem($request->id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/item/get-list-item",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Danh sách sản phẩm",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-list-item",
     *     @OA\Parameter(
     *             in="query",
     *             name="searchFields[]",
     *             required=false,
     *             description="List of fields to search. Example: ['name']",
     *            @OA\Schema(
     *               type="array",
     *               @OA\Items(
     *                 type="string",
     *                 example="name"
     *                )
     *             ),
     *        ),
     *       @OA\Parameter(
     *              in="query",
     *              name="search",
     *              required=false,
     *              description="Name item search. Example: 'Cà phê'",
     *              @OA\Schema(
     *                type="string",
     *                example="Cà phê",
     *              ),
     *         ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListItem()
    {
        try {
            DB::beginTransaction();
            $data = $this->itemInterface->listItemAdmin();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/item/create-item",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Thêm mới sản phẩm",
     *     security={{"bearerAuth":{}}},
     *     operationId="create-item",
     *     @OA\RequestBody(
     *            @OA\JsonContent(
     *                type="object",
     *                @OA\Property(property="name", type="string"),
     *                @OA\Property(property="description", type="string"),
     *                @OA\Property(property="price", type="string"),
     *                @OA\Property(property="itemTypeId", type="string"),
     *                @OA\Property(property="image", type="string"),
     *            @OA\Examples(
     *                summary="Examples",
     *                example = "Examples",
     *                value = {
     *                    "name": "Cà phê sữa",
     *                    "description":"Cà phê",
     *                    "price":"40000",
     *                    "itemTypeId":"1",
     *                    "image":"base-64",
     *                    },
     *                ),
     *            )
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function createItem(ItemRequest $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $this->item->create([
                'name' => $data['name'],
                'description' => $data['description'],
                'price' => $data['price'],
                'itemTypeId' => $data['itemTypeId'],
                'image' => $data['image']
            ]);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/item/update-item/{id}",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Cập nhật sản phẩm",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-item",
     *     @OA\Parameter(
     *            in="path",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="integer",
     *              example=1,
     *            )
     *     ),
     *      @OA\RequestBody(
     *             @OA\JsonContent(
     *                 type="object",
     *                 @OA\Property(property="name", type="string"),
     *                 @OA\Property(property="description", type="string"),
     *                 @OA\Property(property="price", type="string"),
     *                 @OA\Property(property="itemTypeId", type="string"),
     *             @OA\Examples(
     *                 summary="Examples",
     *                 example = "Examples",
     *                 value = {
     *                     "name": "Cà phê sữa",
     *                     "description":"Cà phê",
     *                     "price":"40000",
     *                     "itemTypeId":"1"
     *                     },
     *                 ),
     *             )
     *        ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function updateItem($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $this->item->find($id)->update([
                'name' => $data['name'],
                'description' => $data['description'],
                'price' => $data['price'],
                'itemTypeId' => $data['itemTypeId']
            ]);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Delete (
     *     path="/api/cms/item/delete-item/{id}",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Xóa sản phẩm",
     *     security={{"bearerAuth":{}}},
     *     operationId="delete-item",
     *          @OA\Parameter(
     *            in="query",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function deleteItem($id)
    {
        try {
            DB::beginTransaction();
            $this->itemInterface->deleteItem($id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/item/change-status-item",
     *     tags={"CMS Quản lý sản phẩm"},
     *     summary="Đổi trạng thái",
     *     security={{"bearerAuth":{}}},
     *     operationId="change-status-item",
     *     @OA\Parameter(
     *             in="query",
     *             name="id",
     *             required=true,
     *             description="id",
     *             @OA\Schema(
     *               type="string",
     *               example="1",
     *            ),
     *        ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function changeStatusItem(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $this->itemInterface->changeStatusItem($request->id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
