<?php
//
//namespace App\Http\Controllers\Api\CMS;
//
//use App\Enums\Constant;
//use App\Helpers\CommonHelper;
//use App\Http\Controllers\Controller;
//use App\Http\Requests\CMS\MediaRequest;
//use App\Http\Resources\FileResource;
//use App\Http\Resources\FolderResource;
//use App\Models\File;
//use App\Repositories\File\FileInterface;
//use App\Repositories\Folder\FolderInterface;
//use Illuminate\Http\JsonResponse;
//use Media;
//
//class MediaController extends Controller
//{
//
//    /**
//     * @var FileInterface
//     */
//    protected $fileRepository;
//
//    /**
//     * @var FolderInterface
//     */
//    protected $folderRepository;
//
//    /**
//     * MediaController constructor
//     * @param FileInterface $fileRepository
//     * @param FolderInterface $folderRepository
//     */
//    public function __construct(FileInterface $fileRepository, FolderInterface $folderRepository)
//    {
//        $this->fileRepository   = $fileRepository;
//        $this->folderRepository = $folderRepository;
//    }
//
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/cms/medias/list-file",
//     *     tags={"CMS Quản lí hình ảnh"},
//     *     summary="Danh sách hình ảnh các tab",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="medias/list-file",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *    @OA\Parameter(
//     *           in="query",
//     *           name="folder_id",
//     *           required=false,
//     *           description="Id Of Folder (Anh da upload, thu vien anh, ...)",
//     *           @OA\Schema(
//     *             type="integer",
//     *             example=1,
//     *           ),
//     *      ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function listFile(): JsonResponse
//    {
//        $media = $this->folderRepository
//            ->getModel()
//            ->with('files')
//            ->where('parent_id', 0)
//            ->filter(request(['folder_id']))
//            ->get();
//
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' =>  FolderResource::collection($media)
//        ], Constant::SUCCESS_CODE);
//    }
//
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/cms/medias/list-folder",
//     *     tags={"CMS Quản lí hình ảnh"},
//     *     summary="Danh sách foldes",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="medias/list-folder",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function listFolder(): JsonResponse
//    {
//        $media = $this->folderRepository
//            ->getModel()
//            ->where('parent_id', 0)
//            ->get();
//
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' => $media
//        ], Constant::SUCCESS_CODE);
//    }
//
//    /**
//     * @author Sonnk
//     * @OA\Post(
//     *     path="/api/cms/medias/upload-file",
//     *     tags={"CMS Quản lí hình ảnh"},
//     *     summary="Upload hình ảnh",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="medias/upload-file",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *      @OA\RequestBody(
//     *          @OA\MediaType(
//     *              mediaType="multipart/form-data",
//     *              @OA\Schema(
//     *                  allOf={
//     *                      @OA\Schema(
//     *                           @OA\Property(property="user_id", type="integer", example=1),
//     *                           @OA\Property(property="folder_id", type="integer", example=1),
//     *                           @OA\Property(property="type", type="string", example="upload", description="Truyền upload hoặc editor"),
//     *                           @OA\Property(property="file[]", type="array",
//     *                                @OA\Items(type="string", format="binary")),     *                     )
//     *                       }
//     *                      )
//     *                   )
//     *               ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function uploadFile(MediaRequest $request): JsonResponse
//    {
//        try {
//            $files = $request->file('file');
//            $folder_id = $request->folder_id ?? 0;
//            $type = $request->type;
//            $images = [];
//            foreach($files as $file){
//                if ($type == File::$file_upload) {
//                    $media = Media::handleUploadFile($file, true, $folder_id);
//                    if ($media['error']) {
//                        return response()->json([
//                            'status' => Constant::BAD_REQUEST_CODE,
//                            'message' => $media['message'],
//                            'data' => []
//                        ], Constant::BAD_REQUEST_CODE);
//                    }
//                    $images[] = $media['data'];
//                } elseif ($type == File::$file_editor) {
//                    $media = Media::handleUploadFile($file, false, $folder_id, Constant::PATH_EDITOR);
//                    if (!empty($media['error'])) {
//                        return response()->json([
//                            'status' => Constant::BAD_REQUEST_CODE,
//                            'message' => $media['message'],
//                        ], Constant::BAD_REQUEST_CODE);
//                    }
//                    $images[] = CommonHelper::getUrlFile( $media['url'], Constant::PATH_UPLOAD);
//                }
//            }
//
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => $images
//            ], Constant::SUCCESS_CODE);
//        } catch (\Exception $e) {
//            return response()->json([
//                'status' => Constant::BAD_REQUEST_CODE,
//                'message' => $e->getMessage(),
//            ], Constant::BAD_REQUEST_CODE);
//        }
//
//    }
//
//    /**
//     * @author Sonnk
//     * @OA\Delete  (
//     *     path="/api/cms/medias/delete-file/{id}",
//     *     tags={"CMS Quản lí hình ảnh"},
//     *     summary="Xóa hình ảnh",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="medias/delete",
//     *     @OA\Parameter(
//     *          in="header",
//     *          name="X-localication",
//     *          required=false,
//     *          description="Ngôn ngữ",
//     *          @OA\Schema(
//     *            type="string",
//     *            example="vi",
//     *          )
//     *     ),
//     *     @OA\Parameter(
//     *          in="path",
//     *          name="id",
//     *          required=false,
//     *          description="ID hình ảnh",
//     *          @OA\Schema(
//     *            type="integer",
//     *            example=1,
//     *          ),
//     *     ),
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function deleteFile($id): JsonResponse
//    {
//        try {
//            $file = $this->fileRepository->findById($id);
//
//            if (empty($file)) {
//                return response()->json([
//                    'status' => Constant::NOT_FOUND_CODE,
//                    'message' => trans('messages.errors.media.file_not_found'),
//                    'data' => []
//                ], Constant::NOT_FOUND_CODE);
//            }
//
//            $this->fileRepository->delete($id);
//
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//        } catch (\Exception $e) {
//            return response()->json([
//                'status' => Constant::BAD_REQUEST_CODE,
//                'message' => $e->getMessage(),
//                'data' => []
//            ], Constant::BAD_REQUEST_CODE);
//        }
//    }
//
//}
