<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CMS\MediaRequest;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\User\AuthRequest;
use App\Models\File;
use App\Models\User;
use App\Models\Account;
use App\Services\User\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\User\UserInterface;
use Media;
class AuthController extends Controller
{
    private AuthService $authService;
    private User $user;
    protected $userInterface;
    public function __construct(
        AuthService $authService,
        User $user,
        Account $account,
    )
    {
        $this->authService = $authService;
        $this->user = $user;
        $this->account = $account;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/auth/get-user",
     *     tags={"CMS Tài khoản"},
     *     summary="Thông tin tài khoản",
     *     security={{"bearerAuth":{}}},
     *     operationId="auth/get-admin",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getUser()
    {
        try {
            DB::beginTransaction();
            $user = $this->user->where('id', $this->getCurrentLoggedIn()->userId)->first();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $user
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/auth/login",
     *     tags={"CMS Tài khoản"},
     *     summary="Đăng nhập Admin",
     *     operationId="admin/login",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="userName", type="string"),
     *              @OA\Property(property="password", type="string"),
     *              @OA\Property(property="device_token", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "userName": "admin",
     *                  "password": "123123",
     *                  "device_token": "xxx111xxx",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function login(AuthRequest $request): JsonResponse
    {
        try {
            $user = $this->account->ofUserName($request->userName)
                ->OfRole(Account::$admin)
                ->first();

            if (!$user) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_1',
                    'message' => trans('messages.errors.users.email_not_found'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            if ($user->status == 0) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_2',
                    'message' => trans('messages.errors.users.account_not_active'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            $credentials = [
                'userName' => $request->userName,
                'password' => $request->password
            ];

            if (!Auth::attempt($credentials)) {
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'errorCode' => 'E_UC2_3',
                    'message' => trans('messages.errors.users.password_not_correct'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }


            // xoa token cu
            $user->tokens()->delete();

            $user->update([
                'device_token' => $request->device_token
            ]);

            Log::debug($request);
            $data = [
                'token' => $user->createToken($request->device_token)->plainTextToken,
                'user' => $user
            ];

            return response()->json([
                'status' => Response::HTTP_OK,
                'message' => trans('messages.success.users.login_success'),
                'data' => $data
            ], Response::HTTP_OK);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/auth/logout",
     *     tags={"CMS Tài khoản"},
     *     summary="Đăng xuất",
     *     security={{"bearerAuth":{}}},
     *     operationId="admin/logout",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function logout(): JsonResponse
    {
        try {
            DB::beginTransaction();

            $user = $this->getCurrentLoggedIn();

            if ($user) {
                $user->tokens()->delete();
            } else {
                abort(Constant::UNAUTHORIZED_CODE);
            }

            DB::commit();

            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => 'Đăng xuất thành công!',
                'data' => $user
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/auth/edit-profile",
     *     tags={"CMS Tài khoản"},
     *     summary="Chỉnh sửa thông tin cá nhân",
     *     security={{"bearerAuth":{}}},
     *     operationId="admin/edit-profile",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="name", type="string"),
     *              @OA\Property(property="phone", type="string"),
     *              @OA\Property(property="email", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "name": "Nguyen Van B",
     *                  "phone": "0987654321",
     *                  "email": "emailedit@gmail.com",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function editProfile(AuthRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();

            $user = $this->user->where('id', $this->getCurrentLoggedIn()->userId)->first();
            $data = $request->only('name', 'phone', 'email');

            $this->user->find($user->id)->update($data);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => User::find($user->id)
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/auth/change-password",
     *     tags={"CMS Tài khoản"},
     *     summary="Đổi mật khẩu",
     *     security={{"bearerAuth":{}}},
     *     operationId="admin/change-password",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="old_password", type="string"),
     *              @OA\Property(property="new_password", type="string"),
     *          @OA\Examples(
     *              summary="Examples",
     *              example = "Examples",
     *              value = {
     *                  "old_password": "123123",
     *                  "new_password": "123456",
     *                  },
     *              ),
     *          )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function changePassword(AuthRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();
            $user = $this->getCurrentLoggedIn();
            $old_password = $request->old_password;
            $new_password = $request->new_password;

            $user = Account::find($user->id);
            if(!Hash::check($old_password, $user->password)){
                DB::rollBack();
                return response()->json([
                    'status' => Response::HTTP_BAD_REQUEST,
                    'message' => trans('messages.errors.users.password_not_correct'),
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            $user->update(['password'=> Hash::make($new_password)]);

            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => User::find($user->id)
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
//public function function($request)
//{
//    try {
//        DB::beginTransaction();
//        DB::commit();
//        return response()->json([
//            'status' => Constant::SUCCESS_CODE,
//            'message' => trans('messages.success.success'),
//            'data' => User::find($user->id)
//        ], Constant::SUCCESS_CODE);
//
//    } catch (\Throwable $th) {
//        return response()->json([
//            'status' => Constant::FALSE_CODE,
//            'message' => $th->getMessage(),
//            'data' => []
//        ], Response::HTTP_INTERNAL_SERVER_ERROR);
//    }
//}
