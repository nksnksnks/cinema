<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Models\Provider;
use Illuminate\Http\Request;
use App\Http\Requests\CMS\ProviderRequest;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
class ProviderController extends Controller
{
    protected Provider $provider;
    public function __construct(
        Provider $provider
    )
    {
        $this->provider = $provider;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/provider/get-provider",
     *     tags={"CMS Quản lý nhà cung cấp"},
     *     summary="Tên nhà cung cấp",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-provider",
     *     @OA\Parameter(
     *            in="query",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getProvider(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $this->provider->find($request->id);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/provider/get-list-provider",
     *     tags={"CMS Quản lý nhà cung cấp"},
     *     summary="Danh sách nhà cung cấp",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-list-provider",
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListProvider()
    {
        try {
            DB::beginTransaction();
            $data = $this->provider->get();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/provider/create-provider",
     *     tags={"CMS Quản lý nhà cung cấp"},
     *     summary="Thêm mới nhà cung cấp",
     *     security={{"bearerAuth":{}}},
     *     operationId="create-provider",
     *      @OA\RequestBody(
     *             @OA\JsonContent(
     *                 type="object",
     *                 @OA\Property(property="name", type="string"),
     *                 @OA\Property(property="phone", type="string"),
     *                 @OA\Property(property="address", type="string"),
     *                 @OA\Property(property="email", type="string"),
     *
     *             @OA\Examples(
     *                 summary="Examples",
     *                 example = "Examples",
     *                 value = {
     *                     "name": "Trung Nguyên",
     *                     "phone":"0987968775",
     *                     "address": "HCM",
     *                     "email":"trungnguyen@gmail.com",
     *                     },
     *                 ),
     *             )
     *        ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function createProvider(ProviderRequest $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $this->provider->create($data);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Post (
     *     path="/api/cms/provider/update-provider/{id}",
     *     tags={"CMS Quản lý nhà cung cấp"},
     *     summary="Cập nhật nhà cung cấp",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-provider",
     *     @OA\Parameter(
     *            in="path",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="integer",
     *              example=1,
     *            )
     *     ),
     *     @OA\RequestBody(
     *            @OA\JsonContent(
     *                type="object",
     *                  @OA\Property(property="name", type="string"),
     *                  @OA\Property(property="phone", type="string"),
     *                  @OA\Property(property="address", type="string"),
     *                  @OA\Property(property="email", type="string"),
     *
     *            @OA\Examples(
     *                summary="Examples",
     *                example = "Examples",
     *                value = {
     *                    "name": "Trung Nguyên",
     *                    "phone":"0987968775",
     *                    "address": "HCM",
     *                    "email":"trungnguyen@gmail.com",
     *                    },
     *                ),
     *            )
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function updateProvider($id, ProviderRequest $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $this->provider->find($id)->update($data);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Delete (
     *     path="/api/cms/provider/delete-provider/{id}",
     *     tags={"CMS Quản lý nhà cung cấp"},
     *     summary="Xóa nhà cung cấp",
     *     security={{"bearerAuth":{}}},
     *     operationId="delete-provider",
     *          @OA\Parameter(
     *            in="query",
     *            name="id",
     *            required=true,
     *            description="id",
     *            @OA\Schema(
     *              type="string",
     *              example="1",
     *            ),
     *       ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function deleteProvider($id)
    {
        try {
            DB::beginTransaction();
            $this->provider->find($id)->delete();
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
