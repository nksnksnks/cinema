<?php
//
//namespace App\Http\Controllers\Api\CMS;
//
//use App\Enums\Constant;
//use App\Http\Controllers\Controller;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
//use Symfony\Component\HttpFoundation\Response;
//
//class ProductController extends Controller
//{
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/cms/product/get-product",
//     *     tags={"CMS Quản lý sản phẩm"},
//     *     summary="Tên sản phẩm",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="get-product",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function getProduct($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//    /**
//     * @author Sonnk
//     * @OA\Get (
//     *     path="/api/cms/product/get-list-product",
//     *     tags={"CMS Quản lý sản phẩm"},
//     *     summary="Danh sách sản phẩm",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="get-list-product",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function getListProduct($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/cms/product/create-product",
//     *     tags={"CMS Quản lý sản phẩm"},
//     *     summary="Thêm mới sản phẩm",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="create-product",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function createProduct($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//    /**
//     * @author Sonnk
//     * @OA\Post (
//     *     path="/api/cms/product/update-product",
//     *     tags={"CMS Quản lý sản phẩm"},
//     *     summary="Cập nhật sản phẩm",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="update-product",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function updateProduct($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//    /**
//     * @author Sonnk
//     * @OA\Delete (
//     *     path="/api/cms/product/delete-product",
//     *     tags={"CMS Quản lý sản phẩm"},
//     *     summary="Xóa sản phẩm",
//     *     security={{"bearerAuth":{}}},
//     *     operationId="delete-product",
//     *     @OA\Response(
//     *         response=200,
//     *         description="Success",
//     *             @OA\JsonContent(
//     *              @OA\Property(property="message", type="string", example="Success."),
//     *          )
//     *     ),
//     * )
//     */
//    public function deleteProduct($request)
//    {
//        try {
//            DB::beginTransaction();
//            DB::commit();
//            return response()->json([
//                'status' => Constant::SUCCESS_CODE,
//                'message' => trans('messages.success.success'),
//                'data' => []
//            ], Constant::SUCCESS_CODE);
//
//        } catch (\Throwable $th) {
//            return response()->json([
//                'status' => Constant::FALSE_CODE,
//                'message' => $th->getMessage(),
//                'data' => []
//            ], Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//}
