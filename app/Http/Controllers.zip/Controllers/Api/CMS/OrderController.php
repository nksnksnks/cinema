<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Order\OrderInterface;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class OrderController extends Controller
{
    protected $orderInterface;
    public function __construct
    (
        OrderInterface $orderInterface
    )
    {
        $this->orderInterface = $orderInterface;
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/order/get-list-order",
     *     tags={"CMS Quản lý đơn hàng"},
     *     summary="Danh sách đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-order",
     *     @OA\Parameter(
     *              in="query",
     *              name="searchFields[]",
     *              required=false,
     *              description="List of fields to search. Example: ['status']",
     *             @OA\Schema(
     *                type="array",
     *                @OA\Items(
     *                  type="string",
     *                  example="status"
     *                 )
     *              ),
     *         ),
     *        @OA\Parameter(
     *               in="query",
     *               name="search",
     *               required=false,
     *               description="Name item search. Example:'5' [6=>Chờ giao hàng, 5=>Chờ admin xác nhận]",
     *               @OA\Schema(
     *                 type="string",
     *                 example="5",
     *               ),
     *          ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getListOrder()
    {
        try {
            $data = $this->orderInterface->getListOrder();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Get (
     *     path="/api/cms/order/get-order-detail",
     *     tags={"CMS Quản lý đơn hàng"},
     *     summary="Chi tiết đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="get-order-detail",
     *     @OA\Parameter(
     *              in="query",
     *              name="orderId",
     *              required=true,
     *              description="Id đơn hàng",
     *                @OA\Items(
     *                 type="string",
     *                 example="46"
     *                 )
     *         ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function getOrderDetail(Request $request)
    {
        try {
            $dataRequest = $request->all();
            $data = $this->orderInterface->getOrderDetail($dataRequest['orderId']);
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => $data
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\get (
     *     path="/api/cms/order/update-order-success",
     *     tags={"CMS Quản lý đơn hàng"},
     *     summary="Xác nhận hoàn tất đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-order-success",
     *     @OA\Parameter(
     *               in="query",
     *               name="orderId",
     *               required=true,
     *               description="Id đơn hàng",
     *               @OA\Items(
     *                 type="string",
     *                  example="46"
     *                  )
     *          ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function updateBillSuccess(Request $request)
    {
        $data = $request->all();
        try {
            DB::beginTransaction();
            $this->orderInterface->updateBillSuccess($data['orderId']);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\Delete (
     *     path="/api/cms/order/delete-order",
     *     tags={"CMS Quản lý đơn hàng"},
     *     summary="Xóa đơn hàng",
     *     security={{"bearerAuth":{}}},
     *     operationId="delete-order",
     *          @OA\Parameter(
     *                in="query",
     *                name="orderId",
     *                required=true,
     *                description="Id đơn hàng",
     *                @OA\Items(
     *                  type="string",
     *                   example="46"
     *                   )
     *           ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function deleteOrder(Request $request)
    {
        $data = $request->all();
        try {
            DB::beginTransaction();
            $this->orderInterface->deleteBill($data['orderId']);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @author Sonnk
     * @OA\get (
     *     path="/api/cms/order/update-order-confirmed",
     *     tags={"CMS Quản lý đơn hàng"},
     *     summary="Xác nhận đơn hàng (Chờ giao hàng)",
     *     security={{"bearerAuth":{}}},
     *     operationId="update-order-confirmed",
     *     @OA\Parameter(
     *               in="query",
     *               name="orderId",
     *               required=true,
     *               description="Id đơn hàng",
     *               @OA\Items(
     *                 type="string",
     *                  example="46"
     *                  )
     *          ),
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *             @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Success."),
     *          )
     *     ),
     * )
     */
    public function orderConfirmed(Request $request)
    {
        $data = $request->all();
        try {
            DB::beginTransaction();
            $this->orderInterface->updateBillConfirmed($data['orderId']);
            DB::commit();
            return response()->json([
                'status' => Constant::SUCCESS_CODE,
                'message' => trans('messages.success.success'),
                'data' => []
            ], Constant::SUCCESS_CODE);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => Constant::FALSE_CODE,
                'message' => $th->getMessage(),
                'data' => []
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
