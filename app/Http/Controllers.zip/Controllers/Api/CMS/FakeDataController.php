<?php

namespace App\Http\Controllers\Api\CMS;

use App\Enums\Constant;
use App\Http\Controllers\Controller;
use App\Models\Address;
use App\Models\Bill;
use App\Models\Item;
use App\Models\User;
use App\Models\Account;
use App\Repositories\Cart\CartInterface;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Itemsoder;

class FakeDataController extends Controller{
    protected CartInterface $cartInterface;
    public function __construct(
        CartInterface $cartInterface
    ){
        $this->cartInterface = $cartInterface;
    }
    public function fakeUser(){
        $faker = Faker::create('vi_VN');
        $address = [
            [
                'district' => 'Ba Đình',
                'ward' => ['Phúc Xá', 'Trúc Bạch', 'Vĩnh Phúc', 'Cống Vị', 'Liễu Giai', 'Nguyễn Trung Trực', 'Điện Biên', 'Đội Cấn', 'Ngọc Hà', 'Kim Mã']
            ],
            [
                'district' => 'Hoàn Kiếm',
                'ward' => ['Phúc Tân', 'Đồng Xuân', 'Cửa Đông', 'Lý Thái Tổ', 'Hàng Bồ', 'Hàng Gai', 'Chương Dương Độ', 'Hàng Trống', 'Tràng Tiền']
            ],
            [
                'district' => 'Hai Bà Trưng',
                'ward' => ['Bách Khoa', 'Lê Đại Hành', 'Đống Mác', 'Ngô Thì Nhậm', 'Nguyễn Du', 'Hai Bà Trưng', 'Thanh Nhàn', 'Phạm Đình Hổ', 'Lê Ngọc Hân']
            ],
            [
                'district' => 'Đống Đa',
                'ward' => ['Cát Linh', 'Văn Miếu', 'Quốc Tử Giám', 'Trúc Khê', 'Láng Thượng', 'Láng Hạ', 'Ô Chợ Dừa', 'Phương Liên', 'Thổ Quan']
            ],
            [
                'district' => 'Cầu Giấy',
                'ward' => ['Nghĩa Đô', 'Quan Hoa', 'Dịch Vọng', 'Dịch Vọng Hậu', 'Yên Hòa', 'Trung Hòa', 'Nguyễn Phong Sắc', 'Xuân Thủy', 'Xuân La']
            ],
            [
                'district' => 'Hà Đông',
                'ward' => ['Mộ Lao', 'Vạn Phúc', 'Yết Kiêu', 'Quang Trung', 'La Khê', 'Phú La', 'Phú Lãm', 'Dương Nội', 'Hà Cầu']
            ],
            [
                'district' => 'Tây Hồ',
                'ward' => ['Quảng An', 'Xuân La', 'Nhật Tân', 'Tứ Liên', 'Bưởi', 'Thụy Khuê', 'Xuân La', 'Yên Phụ']
            ],
            [
                'district' => 'Long Biên',
                'ward' => ['Phú Thượng', 'Ngọc Thụy', 'Giang Biên', 'Phúc Đồng', 'Sài Đồng', 'Ngọc Lâm', 'Ngọc Thuỵ', 'Việt Hưng']
            ],
            [
                'district' => 'Thanh Xuân',
                'ward' => ['Hạ Đình', 'Khương Đình', 'Khương Mai', 'Kim Giang', 'Nhân Chính', 'Phương Liệt', 'Thanh Xuân Bắc', 'Thanh Xuân Nam', 'Thượng Đình']
            ],
            [
                'district' => 'Hoàng Mai',
                'ward' => ['Đại Kim', 'Định Công', 'Giáp Bát', 'Hoàng Liệt', 'Hoàng Văn Thụ', 'Linh Đàm', 'Lĩnh Nam', 'Mai Động', 'Tân Mai']
            ],
            [
                'district' => 'Nam Từ Liêm',
                'ward' => ['Cầu Diễn', 'Mễ Trì', 'Mỹ Đình 1', 'Mỹ Đình 2', 'Phú Đô', 'Phương Canh', 'Tây Mỗ', 'Trung Văn', 'Xuân Phương']
            ],
            [
                'district' => 'Bắc Từ Liêm',
                'ward' => ['Cổ Nhuế 1', 'Cổ Nhuế 2', 'Đông Ngạc', 'Đức Thắng', 'Liên Mạc', 'Minh Khai', 'Phú Diễn', 'Tây Tựu', 'Thụy Phương']
            ],
        ];
        for($i=0; $i<700; $i++) {
            $username = $faker->userName;
            $password = '123456';
            $email = $faker->unique()->email;
            $name = $faker->unique()->name;
            $phone = '09' . rand(10000000, 99999999);
            $currentTimestamp = time();
            $randomSeconds = rand(0, 30 * 24 * 60 * 60);
            $randomTimestamp = $currentTimestamp - $randomSeconds;
            $randomDateTime = date("Y-m-d H:i:s", $randomTimestamp);
            $data = User::create([
                'email' => $email,
                'name' => $name,
                'phone' => $phone,
                'branch' => '1',
                'roleId' => User::$user,
                'created_at' => $randomDateTime,
                'updated_at' => $randomDateTime
            ])->id;
            $dataAccount = Account::create([
                'userName' => $username,
                'password' => Hash::make($password),
                'typeAccount' => '1',
                'status' => '1',
                'userId' => $data,
                'roleId' => User::$user,
            ]);
            $this->cartInterface->createCart($data);

            $randomDistrict = $address[array_rand($address)];
            $selectedDistrict = $randomDistrict['district'];
            $randomWard = $randomDistrict['ward'][array_rand($randomDistrict['ward'])];
            $soNha = $faker->numberBetween(1, 999);
            $tenDuong = $faker->streetName;
            $diaChi = "Số $soNha đường $tenDuong";
            $dataAddress = Address::create([
                'city' => 'Hà Nội',
                'district' => $selectedDistrict,
                'ward' => $randomWard,
                'note' => $diaChi,
                'phone' => $phone,
                'customerId' => $data,
                'name' => $name
            ]);
        }
        return 'success';
    }
    public function fakeBill(){
        $faker = Faker::create('vi_VN');

        for($i = 0; $i<1000; $i++) {
            $paymentOptionId = rand(1, 2);

            $deliveryOptionId = rand(1, 2);

            $status = Bill::SUCCESS;

            $customerId = rand(5, 428);
            $customer = User::where('id', '=', $customerId)->first();

            $addressId = Address::where('customerId', '=', $customerId)->first()->id;

            $startTime = strtotime($customer->created_at);
            $currentTimestamp = time();
            $endTime = strtotime('+2 days', $currentTimestamp);
            $randomSeconds = rand($startTime, $endTime);
//            $randomTimestamp = $startTime + $randomSeconds;
            $randomDateTime = date("Y-m-d H:i:s", $randomSeconds);

            $uuid = $randomSeconds;

            $billId = Bill::create([
                'created_att' => $customer->created_at,
                'endtime' => date("Y-m-d H:i:s", $endTime),
                'random' => date("Y-m-d H:i:s", $randomSeconds),
                'addressId' => $addressId,
                'appoimentTime' => 'time',
                'note' => $faker->text,
                'paymentOptionId' => $paymentOptionId,
                'DeliveryOptionId' => $deliveryOptionId,
                'status' => $status,
                'uuid' => $uuid,
                'customer_id' => $customerId,
                'created_at' => $randomDateTime,
                'updated_at' => $randomDateTime
            ])->id;
            $itemNumber = rand(1, 10);
            $min = 18;
            $max = 47;
            $range = range($min, $max);
            shuffle($range);
            for($j=0; $j<$itemNumber; $j++){
                $number = rand(0, 10);
                $itemId = $range[$j];
                $size = rand(0, 2);

                $item = Item::where('id', '=', $itemId)->first();
                $price = $item->price + 5000*$size;
                $itemsOrder = Itemsoder::create([
                    'number' => $number,
                    'itemId' => $itemId,
                    'size' => $size,
                    'price' => $price,
                    'billId' => $billId,
                    'created_at' => $randomDateTime,
                    'updated_at' => $randomDateTime
                ]);
            }
        }
        return 'success';
    }
    public function updateBill(){
//        Itemsoder::where('number', '=', 0)->update([
//            'number' => 1
//        ]);
            $total = Itemsoder::join('bill', 'bill.id', '=', 'itemsoder.billId')
                        ->select([
                            DB::raw('bill.id as id'),
                            DB::raw('SUM(itemsoder.price * itemsoder.number) as total'),
                        ])
                        ->groupBy('bill.id')
                        ->get();
            foreach($total as $i){
                $bill = Bill::where('id', '=', $i['id'])->update([
                    'total' => $i['total']
                ]);
            }
        return 'success';
    }
}
